package com.bean.demo.exception;

public class EmployeeDataAlreadyAvailableFoundException extends Exception{

	public EmployeeDataAlreadyAvailableFoundException(String message) {
		super(message);
	}

}
