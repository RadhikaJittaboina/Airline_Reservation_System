package com.bean.demo.exception;

public class FlightIdNotFoundException extends Exception {

	public FlightIdNotFoundException(String message) {
		super(message);
	}

}
